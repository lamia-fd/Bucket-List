//
//  ViewController.swift
//  Bucket List v2
//
//  Created by لمياء فالح الدوسري on 23/05/1443 AH.
//

import UIKit
import Alamofire

class ViewController: UIViewController ,UITableViewDataSource,UITableViewDelegate{
    var movies:[String] = []
///https://saudibucketlistapi.herokuapp.com/tasks/
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
       // postTaskWithAlamofire()
      
        
       // deleteTaskWithAlamofire()
        updateTaskWithAlamofire()
        print(movies)
        getTaskWithAlamofire()
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movies.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
                cell.textLabel?.text = movies[indexPath.row]
                return cell
    }
    
    func getTaskWithAlamofire() {
        
        AF.request("https://saudibucketlistapi.herokuapp.com/tasks/").responseDecodable(of: [tasks].self) { response in
            guard let photoArr = response.value else { return }
                        
                        self.movies = photoArr.map{ photoObj in
                          //  print("convert photo object to string")
                            return photoObj.objective
                        }
            
            ///self.movies = tasksArray.objective
            DispatchQueue.main.async {
               self.tableView.reloadData()
                print(self.movies)
            }
        }
    }
    
    func postTaskWithAlamofire(){
        let movieObj = tasks.init(objective: "test15")
               
               AF.request("https://saudibucketlistapi.herokuapp.com/tasks/",
                          method: .post,
                          parameters: movieObj).responseDecodable(of: tasks.self) { response in
                   guard response.value != nil else { return }
                
                  
               }
        
    }
    func deleteTaskWithAlamofire(){
               
               AF.request("https://saudibucketlistapi.herokuapp.com/tasks/\(516)",
                          method: .delete).responseDecodable(of: tasks.self) { response in
                   guard response.value != nil else { return }
                
                  
               }
        
    }
    func updateTaskWithAlamofire(){
        let movieObj = tasksto.init(name:"Task",objective: "hi there i am done22" )
               
               AF.request("https://saudibucketlistapi.herokuapp.com/tasks/\(524)/",
                          method: .put,parameters: movieObj).responseDecodable(of: [tasksto].self) { response in
                   guard response.value != nil else { return }
                
                  
               }
        
    }

}

struct tasks:Codable{
    let objective:String
}

struct tasksto:Codable{
    let name:String
    let objective:String

}
//struct objectives:Codable{
//    let objective:String
//}

